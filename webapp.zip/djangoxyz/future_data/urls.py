from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin', admin.site.urls),

    path("", views.screenb1, name="screenb1"),
    path("result_fd", views.result_fd, name="result_fd"),
    #path('changing_specs', views.changing_specs, name='changing_specs'),
    path('pre_result_fd', views.pre_result_fd, name='pre_result_fd'),


]
