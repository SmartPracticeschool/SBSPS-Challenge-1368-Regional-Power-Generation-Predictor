from django.apps import AppConfig


class FutureDataConfig(AppConfig):
    name = 'future_data'
