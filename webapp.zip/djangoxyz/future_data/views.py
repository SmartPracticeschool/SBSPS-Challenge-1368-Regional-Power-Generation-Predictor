from django.shortcuts import render
import datetime
from bs4 import BeautifulSoup
import requests
import itertools
from datetime import date
import calendar

# def screenb0(request):
#     return render(request,"future_data/pre_result_fd.html")



def screenb1(request):
    radius = request.POST.get('radius')
    efficiency = request.POST.get('efficiency')

    print(radius)
    print(efficiency)

    return render(request,"future_data/fd.html" )



def pre_result_fd(request):
    return render(request, "future_data/pre_result_fd.html")



def result_fd(request):
    # air_density1 = request.POST.get('air_density')
    radius1=request.POST.get('radius1')
    efficiency1=request.POST.get('efficiency1')
    windmill_no = request.POST.get('windmill_no')

    print('rad',radius1)
    print('eff',efficiency1)
    print(windmill_no)
    power_req=request.POST.get('power_req', False)
    print(power_req)

    city = request.POST.get('city_name2', False)
    date1 = request.POST.get('date2', False)
    radius = request.POST.get('radius', False)
    efficiency = request.POST.get('efficiency', False)
    air_density = request.POST.get('air_density', False)
    dat_lis2=[]

    dat_lis=date1.split('-')
    date2 = '{} {} {}'.format(dat_lis[2],dat_lis[1],dat_lis[0])
    day_name= ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday','Sunday']
    day = datetime.datetime.strptime(date2, '%d %m %Y').weekday()
    target=day_name[day]#target day
    # week_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    # l = list(map(int, input("Enter date \n eg: 05/05/2019 \n\n").split('/')))
    # today1 = datetime.date(l[2], l[1], l[0]).weekday()
    today_date = date.today()
    today_date2 = str(today_date)
    dat_lis = today_date2.split('-')
    date2 = '{} {} {}'.format(dat_lis[2], dat_lis[1], dat_lis[0])
    day_name = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    day = datetime.datetime.strptime(date2, '%d %m %Y').weekday()
    today1 = day_name[day]
    #convert day to numbers


    if (today1.lower() == 'monday'):
        dat2="tuesday"
        dat3="wednesday"
        dat4="thursday"
        dat5="friday"
        dat6='saturday'
        dat7='sunday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)
    elif (today1.lower() == 'tuesday'):
        dat2="wednesday"
        dat3="thursday"
        dat4="friday"
        dat5="saturday"
        dat6='sunday'
        dat7='monday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)

    elif (today1.lower() == 'wednesday'):
        dat2="thursday"
        dat3="friday"
        dat4="saturday"
        dat5="sunday"
        dat6='monday'
        dat7='tuesday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)
    elif today1.lower() == 'thursday':
        dat2="friday"
        dat3="saturday"
        dat4="sunday"
        dat5="monday"
        dat6='tuesday'
        dat7='wednesday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)

    elif (today1.lower() == 'friday'):
        dat2="saturday"
        dat3="sunday"
        dat4="monday"
        dat5="tuesday"
        dat6='wednesday'
        dat7='thursday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)

    elif (today1.lower() == 'saturday'):
        dat2="sunday"
        dat3="monday"
        dat4="tuesday"
        dat5="wednesday"
        dat6='thursday'
        dat7='friday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)
    elif (today1.lower() == 'sunday'):
        dat2="monday"
        dat3="tuesday"
        dat4="wednesday"
        dat5="thursday"
        dat6='friday'
        dat7='saturday'
        dat_lis2.append(dat2)
        dat_lis2.append(dat3)
        dat_lis2.append(dat4)
        dat_lis2.append(dat5)
        dat_lis2.append(dat6)
        dat_lis2.append(dat7)

    else:
        pass
    if target.lower() == today1:
        day_number = 1
    else:
        index = dat_lis2.index(target.lower())
        day_number = index+2
    API = "pGXdvkVtBFC0SsTgUjBgvHz1ZYPHuO2I"
    countryCode = "IN"
    aaa = "http://dataservice.accuweather.com/locations/v1/cities/"
    bbb = "/search?apikey=pGXdvkVtBFC0SsTgUjBgvHz1ZYPHuO2I&q="
    ccc = "&details=true"
    search_address = aaa + countryCode + bbb + city + ccc
    json_data1 = requests.get(search_address).json()
    location_key = json_data1[0]['Key']
    link1 = 'https://www.accuweather.com/en/in/'
    symbol = '/'
    link2p2 = '/hourly-weather-forecast/'
    link2p3 = '?day='
    link2 = symbol + location_key + link2p2 + location_key + link2p3
    link_final = (link1 + city + link2 + str(day_number))




    lis2 = []
    lis3 = []
    index_solar=['1 AM','2 AM','3 AM','4 AM','5 AM','6 AM','7 AM','8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM','6 PM','7 PM','8 PM','9 PM','10 PM','11 PM','12 PM']
    wind_sp = []
    lis_comment = []
    power_gen=[]
    solar_time=[]
    agent = {"User-Agent": "Mozilla/5.0"}
    page = requests.get(link_final,headers=agent).text
    #page = requests.get('https://www.accuweather.com/en/in/bengaluru/1-204108_1_al/hourly-weather-forecast/1-204108_1_al?day=2', headers=agent).text
    soup = BeautifulSoup(page, 'lxml')

    for i in soup.find_all('div', class_='hourly-card-nfl-header'):
        comment = i.find('span', class_='phrase')
        lis_comment.append(comment.text)

    wind1 = soup.find('div', class_='panel left')
    # wind2=wind1.find('span',class_='value')
    for i in wind1.find('span', class_='value'):
        lis3.append(i)

    for i in soup.find_all('span', class_='value'):
        # lis_comment2=i.find('span',class_='value')
        lis2.append(i.text)

    lis5 = []
    lis7 = []

    for i in lis2:
        if 'km/h' in i:
            lis7.append(i)
        else:
            pass
    index_wind = 0
    while index_wind <= 47:
        lis5.append(lis7[index_wind])
        index_wind += 2



    hehe0 = [i.strip('''WSW''') for i in lis5]
    hehe = [i.strip('''NW''') for i in hehe0]
    hehe2 = [i.strip("km/h") for i in hehe]
    wind_final = [i.strip(" ") for i in hehe2]

    # comment final##########################################################################################################
    comment_final = [i.strip('''\n\t\t\t''') for i in lis_comment]
    element = comment_final[0]
    del comment_final[0]
    comment_final.insert(len(comment_final), element)
    # print(comment_final)

    # wind speed km/h #########################################################################################################

    element2 = wind_final[0]
    del wind_final[0]
    wind_final.insert(len(wind_final), element2)

    if len(radius1) == 0 :
        radi = 30
    else:
        radi = int(radius1)
    print('radi:',radi)
    if len(efficiency1) == 0 :
        eff = 59
    else:
        eff = int(efficiency1)
    print(eff)
    if len(windmill_no) == 0 :
        w_no = 1
    else:
        w_no = int(windmill_no)
    print(w_no)


    for i in range(0,24):
        j=(int(wind_final[i])*int(wind_final[i])*int(wind_final[i])* 1.5707 * radi * radi * eff * 1.225 * 0.277778 * w_no)/100000
        # j=(1.57 * 54 * 54 * int(wind_final[i]) * int(wind_final[i]) * int(wind_final[i])) * 1.225 * 57 * 0.277) / 1000
        power_gen.append(j)
    total_power=sum(power_gen)
    print(total_power)
    print("req:",len(power_req))
    if len(power_req) == 0 :
        requirement = 15000
    else:
        requirement = int(power_req)
    print('req',requirement)
    print('tot power', total_power)

    if total_power > requirement:
        comment_on_power = "Wind will be generating {} Kw/hr excess power".format(total_power - requirement)
    elif total_power == requirement:
        comment_on_power = "Wind will be generating exact power needed"
    else:
        comment_on_power = "The wind energy will be insufficient by {} Kw/hr".format(requirement - total_power)
        if len(solar_time) == 0:
            solar_time_final = "Use diesel generators to fill up for shortfall"

        else:
            solar_time_final = "Solar may be used during following time: {}".format(solar_time)
    print(comment_final)
    for i in comment_final:
        if i.lower() == 'mostly sunny' or i.lower() == 'sunny':
            solar_time.append(index_solar[i])

        else:
            pass



    time2=['1 AM','2 AM','3 AM','4 AM','5 AM','6 AM','7 AM','8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','2 PM','3 PM','4 PM','5 PM','6 PM','7 PM','8 PM','9 PM','10 PM','11 PM','12 PM']
    p = list(zip(time2, wind_final, power_gen, comment_final))
    indexpqr=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
    return render(request, "future_data/fd_op.html", {'city':city, 'time': time2 , 'comment_final': comment_final,'wind_speed':wind_final, 'power_gen': power_gen,'wind_total_power':total_power,"comment_on_power":comment_on_power,'solar_time_final':solar_time_final,'p':p})





    # if city == "Pune" and date == '2020-06-26':

    #     import xlrd
    #     import xlsxwriter
    #     import openpyxl
    #     from xlutils.copy import copy

    #     workbook = xlrd.open_workbook('Data_thursday.xlsx')
    #     sheet = workbook.sheet_by_index(0)
    #     row_count = sheet.nrows
    #     lis1 = []
    #     lis2 = []
    #     lis3 = []
    #     lis5 = []
    #     dict1 = {}
    #     dict2 = {}
    #     dicttime = {}
    #     time = 1
    #     time2 = 1
    #     rw_no = 1
    #     n1 = 1
    #     n2 = 0
    #     short_fall = "N/A"
    #     excess =  "N/A"
    #     solar_time = "N/A"
    #     xyz = []

    #     def solar():
    #         n1 = -1
    #         n2 = -1

            # n = -1  # index of lis3
            # for i in range(1, row_count):
            #     solar5 = sheet.cell_value(i, 1)  # lis2=theory
            #     lis2.append(solar5)

    #         for i in range(1, row_count):
    #             solar3 = sheet.cell_value(i, 0)
    #             lis3.append(solar3)  # lis3=times

    #     for i in range(1, row_count):
    #         sv = sheet.cell_value(i, 2)
    #         lis1.append(sv)
    #     for speed in lis1:
    #         dict2[time] = speed
    #         time += 1
    #     for i in dict2:

    #         if dict2[i] < 3.3:
    #             dict2[i] = 0
    #         elif dict2[i] > 20:
    #             dict2[i] = 0
    #         else:
    #             dict2[i] = (0.5 * 1.23 * 2826 * dict2[i] * dict2[i] * dict2[i]) / 1000

    #     rb = xlrd.open_workbook('Data_thursday.xlsx')
    #     wb = copy(rb)

    #     w_sheet = wb.get_sheet(0)
    #     ml = 1
    #     for j in range(1, 25):
    #         w_sheet.write(j, 5, dict2[ml])
    #         wb.save('Data_thursday.csv')
    #         ml += 1
    #     need = 15000
    #     sum = 0
    #     for i in dict2:
    #         sum += dict2[i]
    #     if sum < need:
    #         short_fall='There is shortfall of {} W is we use only wind mills'.format(need-sum)
    #         solar()
    #         for i in lis2:
    #             if i == "Partly Cloudy":
    #                 xyz.append(n1)
    #             n1 += 1




    #     elif sum > need:
    #         short_fall = 'Excess Power Generated:', sum - need
    #         n1 += 1
    #     else:
    #         short_fall='Requirements Stisfied.'
    #         n1 += 1
    #     w_sheet.write(27, 5, sum)
    #     wb.save('Data_thursday.csv')
    #     # print(lis2[n1])
    #     solar_time = xyz

    #     print(dict2)
    #     return render(request, "future_data/fd_op.html", {'short_fall':short_fall,'excess':excess,'solar_time':solar_time})
    # else:
    #     return render(request,"future_data/fd_op_negative.html" )

# def changing_specs(request):
#     return render(request,'future_data/pre_result_fd.html')




