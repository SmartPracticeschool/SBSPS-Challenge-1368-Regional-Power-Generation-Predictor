from django.shortcuts import render
from django.http import HttpResponse
from current_data import views as cd_views

posts = [
	{
		'author':'xyz',
		'title':'blog p1',
		'content':'second post content',
		'date':'5',
	}
]
# Create your views here.

def home(request):
	context={

			'posts': posts
	}
	return render(request, 'blog/home.html',context)