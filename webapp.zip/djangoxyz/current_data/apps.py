from django.apps import AppConfig


class CurrentDataConfig(AppConfig):
    name = 'current_data'
